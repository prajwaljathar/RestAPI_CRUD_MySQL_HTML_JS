/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.studentdetail;

import java.util.Date;

/**
 *
 * @author prajwal.j
 */

public class Studentdetails {

    private int rollno;
    private String pname;
    private String dob;
    private int fees;
    public String status="success"; 

    public Studentdetails() {

    }

    public Studentdetails(int rollno, String pname, String dob, int fees,String success) {
        super();
        this.rollno = rollno;
        this.pname = pname;
        this.fees = fees;
        this.dob =dob;
        
       
    }

    public int getrollno() {
        return rollno;
    }

    public void setrollno(int rollno) {
        this.rollno = rollno;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getdob() {
        return dob;
    }

    public void setdob(String dob) {
        this.dob = dob;
    }
    


    public int getfees() {
        return fees;
    }

    public void setfees(int fees) {
        this.fees = fees;
        
    }

    

    
}
