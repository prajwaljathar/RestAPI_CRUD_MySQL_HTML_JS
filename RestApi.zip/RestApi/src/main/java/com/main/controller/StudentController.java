/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.controller;

/**
 *
 * @author prajwal.j
 */
import com.main.service.DbConnection;
import com.main.studentdetail.Studentdetails;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.main.service.DbConnection;
import com.main.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import static org.springframework.http.ResponseEntity.status;

@RestController
@RequestMapping("/student")
@ResponseStatus(HttpStatus.OK)
public class StudentController {

    DbConnection Db = new DbConnection();
    @Autowired
    StudentService studentservice;

            

//@GetMapping("/getStudent")
//public ArrayList<HashMap<String, Object>> getAllStudent() {
//
//        return Db.getRecordList();
//
//    }
    
@GetMapping("/getStudent")
public List<Studentdetails> getAllStudent() {

       return Db.getRecordList();

    } 
    
    
    
    
    
    
    
    
    
    

    @PostMapping("/addStudent")
    public Studentdetails addStudent(@RequestBody Studentdetails studentdetails) {

        Db.addRecord(studentdetails);
        System.out.println("added");
        return studentdetails;
       
    }

    @PutMapping("/updateStudent/{rollno}")
    public Studentdetails updateStudent(@RequestBody Studentdetails studentdetails) {
        System.out.println(studentdetails.getrollno());
        int rows = Db.updateRecord(studentdetails);
        System.out.println(rows + "affected");
        return studentdetails;
    }

    @DeleteMapping("/deleteStudent/{rollno}")
    public Studentdetails deleteStudent(@PathVariable("rollno") int rollno, Studentdetails studentdetails) {

        Db.deleteRecord(rollno);
        return studentdetails;
    }

    @GetMapping("/getStudentByrollno/{rollno}")
    public Studentdetails getStudentByrollno(@PathVariable("rollno") int rollno) {

        return Db.getRecordByrollno(rollno);
    }

}
