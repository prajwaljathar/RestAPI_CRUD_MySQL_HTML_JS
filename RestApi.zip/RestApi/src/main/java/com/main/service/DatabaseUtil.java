/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.main.service;

/**
 *
 * @author prajwal.j
 */


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseUtil {
  public static Connection getConn() throws SQLException, IOException {
    Properties props = new Properties();
    props.load(DatabaseUtil.class.getResourceAsStream("/database.properties"));

    String url = props.getProperty("url");
    String user = props.getProperty("user");
    String password = props.getProperty("password");

    return DriverManager.getConnection(url, user, password);
  }
}