/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.service;

/**
 *
 * @author prajwal.j
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//import com.cory.staff.bean.Staff; 
import com.main.studentdetail.Studentdetails;

import com.main.service.DbConnection;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    static HashMap<Integer, Studentdetails> StudentdetailsIdMap = getStudentdetailsIdMap();

    DbConnection Db = new DbConnection();

    public StudentService() {
        super();

        if (StudentdetailsIdMap == null) {
            StudentdetailsIdMap = new HashMap<Integer, Studentdetails>();
        }
    }

    public List<Studentdetails> getAllStudent() {
        List<Studentdetails> studentdetails = new ArrayList<Studentdetails>(StudentdetailsIdMap.values());
        return studentdetails;
    }

    public Studentdetails getStudent(int rollno) {

        Studentdetails studentdetails = StudentdetailsIdMap.get(rollno);

        System.out.println("here");
        return studentdetails;

    }

    public Studentdetails addStudent(Studentdetails studentdetails) {
        studentdetails.setrollno(StudentdetailsIdMap.size() + 1);
        StudentdetailsIdMap.put(studentdetails.getrollno(), studentdetails);
        return studentdetails;
    }

    public Studentdetails updateStudent(int rollno, Studentdetails studentdetails) {

        if (studentdetails.getrollno() <= 0) {
            return null;
        }

        StudentdetailsIdMap.put(rollno, studentdetails);
        return studentdetails;

    }

    public int deleteStudent(int rollno) {
        StudentdetailsIdMap.remove(rollno);
        return rollno;

    }

    public static HashMap<Integer, Studentdetails> getStudentdetailsIdMap() {
        return StudentdetailsIdMap;
    }

}
