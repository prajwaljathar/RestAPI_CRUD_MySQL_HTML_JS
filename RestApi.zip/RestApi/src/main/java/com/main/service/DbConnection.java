/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.service;

/**
 *
 * @author prajwal.j
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import com.main.studentdetail.Studentdetails;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

public class DbConnection {

    //chore: choose one
    ArrayList<HashMap<String, Object>> table = new ArrayList<HashMap<String, Object>>();
    @Autowired
    DatabaseUtil databaseutil;
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    ResultSetMetaData rsmd = null;
    @Autowired
    Studentdetails studentdetails;

    public Connection connect() {
        try {

            conn = databaseutil.getConn();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;
    }

    public Studentdetails getRecordByrollno(int rollno) {
        Studentdetails row = new Studentdetails();

        try {
            conn = connect();
            String sql = "select rollno,pname,dob,fees  from Student WHERE rollno = ?";
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setInt(1, rollno);
            rs = psmt.executeQuery();

            rsmd = rs.getMetaData();

            while (rs.next()) {

                row.setrollno(rs.getInt("rollno"));
                row.setPname(rs.getString("pname"));
                row.setdob(rs.getString("dob"));
                row.setfees(rs.getInt("fees"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try {
                rs.close();
            } catch (Exception e) {
            }
            if (stmt != null) try {
                stmt.close();
            } catch (Exception e) {
            }
            if (conn != null) try {
                conn.close();
            } catch (Exception e) {
            }
        }

        return row;
    }

    public int updateRecord(Studentdetails studentdetails) {
        int rows = 0;

        try {
            conn = connect();
            String sql = "UPDATE Student SET pname=?, fees=?, dob=? WHERE rollno=?";
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setInt(4, studentdetails.getrollno());
            psmt.setInt(2, studentdetails.getfees());
            psmt.setString(3, studentdetails.getdob());
            psmt.setString(1, studentdetails.getPname());

            rows = psmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try {
                rs.close();
            } catch (Exception e) {
            }
            if (stmt != null) try {
                stmt.close();
            } catch (Exception e) {
            }
            if (conn != null) try {
                conn.close();
            } catch (Exception e) {
            }
        }
        return rows;
    }

    public int deleteRecord(int rollno) {
        int rows = 0;

        try {
            conn = connect();
            String sql = "DELETE FROM Student WHERE rollno=?";
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setInt(1, rollno);

            rows = psmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try {
                rs.close();
            } catch (Exception e) {
            }
            if (stmt != null) try {
                stmt.close();
            } catch (Exception e) {
            }
            if (conn != null) try {
                conn.close();
            } catch (Exception e) {
            }
        }
        return rows;
    }

    public int addRecord(Studentdetails studentdetail) {
        int rows = 0;

        try {
            conn = connect();
            String sql = "INSERT INTO Student (rollno, pname, dob, fees) VALUES (?, ?, ?, ?)";
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setInt(1, studentdetail.getrollno());
            psmt.setString(3, studentdetail.getdob());
            psmt.setString(2, studentdetail.getPname());
            psmt.setInt(4, studentdetail.getfees());

            rows = psmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try {
                rs.close();
            } catch (Exception e) {
            }
            if (stmt != null) try {
                stmt.close();
            } catch (Exception e) {
            }
            if (conn != null) try {
                conn.close();
            } catch (Exception e) {
            }
        }

        return rows;
    }

//    public ArrayList<HashMap<String, Object>> getRecordList() {
//
//        try {
//            conn = connect();
//            String sampleSQL = "SELECT * from Student";
//            stmt = conn.createStatement();
//            rs = stmt.executeQuery(sampleSQL);
//
//            System.out.print(rs);
//
//            rsmd = rs.getMetaData();
//            int cCount = rsmd.getColumnCount();
//
//            while (rs.next()) {
//                HashMap<String, Object> row = new HashMap<String, Object>();
//
//                for (int i = 1; i <= cCount; i++) {
//
//                    row.put(rsmd.getColumnName(i), rs.getObject(i));
//              
                 
//                    
//                }
//
//                table.add(row);
//
//            }
//
//        } 
//        
//        
//        
//        

    /**
     *
     * @return
     */
    public List<Studentdetails> getRecordList() {
     List<Studentdetails> resultList = new ArrayList<>();
        try {
            conn = connect();
            String sampleSQL = "SELECT * from Student";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sampleSQL);

            // Retrieve the ResultSet as a DTO
            
            Studentdetails dto = new Studentdetails(); 
            while (rs.next()) {
               
                dto.setrollno(rs.getInt("rollno"));
                dto.setPname(rs.getString("pname"));
                dto.setdob(rs.getString("dob"));
                dto.setfees(rs.getInt("fees"));
                resultList.add(dto);
            }
            
            // Do something with the DTOs

        }
        
        catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try {
                rs.close();
            } catch (Exception e) {
            }
            if (stmt != null) try {
                stmt.close();
            } catch (Exception e) {
            }
            if (conn != null) try {
                conn.close();
            } catch (Exception e) {
            }
        }

        return resultList;
    }}
